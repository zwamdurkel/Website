<?php 
/*if ( !$_SESSION['login'] ) {
    header("Location: login");
} */
include('./header.php')
?>        
        <!-- Start Content -->
        <div>
            <h1>test2</h1>
        </div>
        <div class="mt-md-0 mt-5">
            <h1>Test</h1>
        </div>
        <!-- End Content -->
<?php include('./footer.php')?>        