<?php
$servername = "localhost";
$dbUser = "root";
$dbPass = "XVgKDOt8F9h4peWz";
$dbName = "login";

$conn = mysqli_connect($servername, $dbUser, $dbPass, $dbName);

if (!$conn) {
    die("Connection failed: ".mysqli_connect_error());


}
// filerun db pw: Ww8QGsronfYsUYNv
// filerun username: superuser
// filerun pw: 6f191f0675ab
?>
